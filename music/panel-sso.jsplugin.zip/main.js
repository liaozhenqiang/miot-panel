(()=>{async function n(){console.log("[panel-sso] ready")}async function o(){console.log("[panel-sso] stopped")}globalThis.onInit=n;globalThis.onDeinit=o;})();
